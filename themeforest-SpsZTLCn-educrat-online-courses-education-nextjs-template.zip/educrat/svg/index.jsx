import ShapeRendering from "./shape-rendering";

export {
  ShapeRendering,
}