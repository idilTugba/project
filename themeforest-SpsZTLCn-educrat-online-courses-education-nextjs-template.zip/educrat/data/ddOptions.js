export const options = [
  { id: 1, label: "Banking" },
  { id: 2, label: "Digital & Creative" },
  { id: 3, label: "Retail" },
  { id: 4, label: "Designer" },
  { id: 5, label: "Developer" },
];
