export const reviews = [
  {
    id: 1,
    avatarSrc: "/assets/img/avatars/1.png",
    name: "Ali Tufan",
    date: "3 Days ago",
    rating: 5,
    title: "The best LMS Design",
    comment:
      "This course is a very applicable. Professor Ng explains precisely each algorithm and even tries to give an intuition for mathematical and statistic concepts behind each algorithm. Thank you very much.",
  },
  {
    id: 2,
    avatarSrc: "/assets/img/avatars/1.png",
    name: "Ali Tufan",
    date: "3 Days ago",
    rating: 5,
    title: "The best LMS Design",
    comment:
      "This course is a very applicable. Professor Ng explains precisely each algorithm and even tries to give an intuition for mathematical and statistic concepts behind each algorithm. Thank you very much.",
  },
  {
    id: 3,
    avatarSrc: "/assets/img/avatars/1.png",
    name: "Ali Tufan",
    date: "3 Days ago",
    rating: 5,
    title: "The best LMS Design",
    comment:
      "This course is a very applicable. Professor Ng explains precisely each algorithm and even tries to give an intuition for mathematical and statistic concepts behind each algorithm. Thank you very much.",
  },
  // Add more comment objects as needed
];
