export const accordionItems = [
  {
    id: 1,
    title: "Starred",
    content: [
      {
        id: 2,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      {
        id: 1,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      // Add more content objects here if needed
    ],
  },
  {
    id: 2,
    title: "Group",
    content: [
      {
        id: 1,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      {
        id: 2,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      {
        id: 3,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      // Add more content objects here if needed
    ],
  },
  {
    id: 3,
    title: "Private",
    content: [
      {
        id: 1,
        name: "Darlene Robertson",
        message: "Hello",
        time: "35 mins",
        imageSrc: "/assets/img/dashboard/right-sidebar/messages/1.png",
      },
      // Add more content objects here if needed
    ],
  },
];
