export const links = [
  { id: 1, href: "/help-center", label: "Help" },
  { id: 2, href: "/terms", label: "Privacy Policy" },
  { id: 3, href: "/terms", label: "Cookie Notice" },
  { id: 4, href: "/terms", label: "Security" },
  { id: 5, href: "/terms", label: "Terms of Use" },
];
