export const slidesData = [
  {
    id: 1,
    bgImage: "/assets/img/home-2/mainSlider/bg.png",
  },
  {
    id: 2,
    bgImage: "/assets/img/home-2/mainSlider/bg.png",
  },
  {
    id: 3,
    bgImage: "/assets/img/home-2/mainSlider/bg.png",
  },
];
