import React from "react";

export default function Line() {
  return (
    <div className="line px-50">
      <div className="line__item bg-light-5"></div>
    </div>
  );
}
